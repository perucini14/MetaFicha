import { useState, type FormEvent } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { TrendingUp, Mail, Lock, LogIn, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Entrar — MetaFlow" },
      { name: "description", content: "Acesse o MetaFlow para acompanhar suas metas de vendas e faturamento." },
      { property: "og:title", content: "Entrar — MetaFlow" },
      { property: "og:description", content: "Acesse o MetaFlow para acompanhar suas metas de vendas e faturamento." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const [entrando, setEntrando] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setErro("");
    setEntrando(true);
    try {
      await login(email.trim(), senha);
      toast.success("Bem-vindo de volta! 👋");
      navigate({ to: "/", replace: true });
    } catch {
      setErro("E-mail ou senha incorretos. Tente novamente.");
    } finally {
      setEntrando(false);
    }
  }

  return (
    <div className="flex min-h-screen">
      {/* Lado esquerdo — identidade (desktop) */}
      <div className="hidden w-1/2 flex-col justify-between bg-sidebar p-12 text-sidebar-foreground lg:flex">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-primary">
            <TrendingUp className="h-6 w-6 text-primary-foreground" />
          </div>
          <div>
            <p className="text-lg font-bold text-sidebar-accent-foreground">MetaFlow</p>
            <p className="text-xs text-sidebar-foreground/60">Vendas & Faturamento</p>
          </div>
        </div>

        <div>
          <h1 className="max-w-md text-4xl font-extrabold leading-tight text-sidebar-accent-foreground">
            Controle suas metas de vendas em um só lugar.
          </h1>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-sidebar-foreground/70">
            Registre vendas, acompanhe o faturamento e veja em tempo real quanto falta
            para atingir sua meta financeira.
          </p>
          <div className="mt-8 flex gap-8">
            <div>
              <p className="text-2xl font-bold text-sidebar-accent-foreground">R$ 50 mil</p>
              <p className="text-xs text-sidebar-foreground/60">Meta do período</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-sidebar-accent-foreground">65%</p>
              <p className="text-xs text-sidebar-foreground/60">Atingimento</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-sidebar-accent-foreground">32</p>
              <p className="text-xs text-sidebar-foreground/60">Vendas realizadas</p>
            </div>
          </div>
        </div>

        <p className="text-xs text-sidebar-foreground/40">
          Projeto acadêmico — Desenvolvimento de Software Visual
        </p>
      </div>

      {/* Lado direito — formulário */}
      <div className="flex w-full items-center justify-center bg-background px-4 py-10 lg:w-1/2">
        <div className="w-full max-w-md">
          {/* Logo mobile */}
          <div className="mb-8 flex items-center justify-center gap-3 lg:hidden">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-primary">
              <TrendingUp className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <p className="text-lg font-bold text-foreground">MetaFlow</p>
              <p className="text-xs text-muted-foreground">Vendas & Faturamento</p>
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-card p-8 shadow-card">
            <h2 className="text-2xl font-bold text-card-foreground">Entrar na sua conta</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Acesse o painel e acompanhe suas vendas.
            </p>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div>
                <label htmlFor="email" className="mb-1.5 block text-sm font-medium text-card-foreground">
                  E-mail
                </label>
                <div className="relative">
                  <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <input
                    id="email"
                    type="email"
                    required
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="seu@email.com"
                    className="w-full rounded-lg border border-input bg-background py-2.5 pl-10 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="senha" className="mb-1.5 block text-sm font-medium text-card-foreground">
                  Senha
                </label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <input
                    id="senha"
                    type="password"
                    required
                    autoComplete="current-password"
                    value={senha}
                    onChange={(e) => setSenha(e.target.value)}
                    placeholder="••••••••"
                    className="w-full rounded-lg border border-input bg-background py-2.5 pl-10 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              </div>

              {erro && (
                <p className="rounded-lg bg-destructive/10 px-3 py-2 text-sm font-medium text-destructive">
                  {erro}
                </p>
              )}

              <button
                type="submit"
                disabled={entrando}
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60"
              >
                {entrando ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <LogIn className="h-4 w-4" />
                )}
                {entrando ? "Entrando..." : "Entrar"}
              </button>
            </form>

            <div className="mt-6 rounded-lg bg-muted px-4 py-3">
              <p className="text-xs font-semibold text-muted-foreground">Acesso de demonstração</p>
              <p className="mt-1 text-xs text-muted-foreground">
                E-mail: <span className="font-medium text-foreground">lucas.minosso@email.com</span>
                <br />
                Senha: <span className="font-medium text-foreground">123456</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
