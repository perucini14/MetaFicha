// ============================================================
// AUTENTICAÇÃO (sessão local)
// ------------------------------------------------------------
// Hoje: login mockado — valida contra o usuário de demonstração
// e guarda a sessão em localStorage.
// Futuro: trocar por POST /api/auth/login na API ASP.NET Core,
// que retornará o usuário + token JWT. A interface (login/logout)
// já está pronta para isso.
// ============================================================

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Usuario } from "./types";
import * as api from "@/services/api";

const SESSION_KEY = "metaflow-session";

interface AuthState {
  usuario: Usuario | null;
  autenticado: boolean;
  /** true quando a sessão salva no navegador já foi lida (evita erro de hidratação SSR) */
  pronto: boolean;
  login: (email: string, senha: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthState | null>(null);

function lerSessao(): Usuario | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as Usuario) : null;
  } catch {
    return null;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  // Começa vazio no servidor e no primeiro render do cliente;
  // a sessão salva é lida só após a montagem (evita hydration mismatch).
  const [usuario, setUsuario] = useState<Usuario | null>(null);
  const [pronto, setPronto] = useState(false);

  useEffect(() => {
    setUsuario(lerSessao());
    setPronto(true);
  }, []);

  const login = useCallback(async (email: string, senha: string) => {
    const u = await api.login(email, senha);
    localStorage.setItem(SESSION_KEY, JSON.stringify(u));
    setUsuario(u);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(SESSION_KEY);
    setUsuario(null);
  }, []);

  const value = useMemo<AuthState>(
    () => ({ usuario, autenticado: usuario !== null, pronto, login, logout }),
    [usuario, pronto, login, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de <AuthProvider>");
  return ctx;
}
