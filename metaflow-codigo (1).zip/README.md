# MetaFlow — Controle de Metas de Vendas

Sistema de controle de metas financeiras relacionadas a vendas, desenvolvido para o projeto acadêmico de Desenvolvimento de Software Visual.

## Rodando o projeto no VS Code

1. Instale o [Node.js](https://nodejs.org) 20 ou superior
2. Abra esta pasta no VS Code (`File → Open Folder`)
3. Abra o terminal do VS Code (`Ctrl + '` / Terminal → New Terminal) e rode:

```sh
npm install
npm run dev
```

4. Acesse `http://localhost:8080` no navegador

**Login de demonstração:**
- E-mail: `lucas.minosso@email.com`
- Senha: `123456`

## Estrutura

- `src/routes/` — páginas (Dashboard, Minhas Metas, Vendas, Relatórios, Perfil, Login)
- `src/components/` — layout (sidebar) e modais (Meta, Venda, confirmação)
- `src/lib/` — regras de negócio (cálculos), tipos, autenticação e estado global
- `src/services/` — camada de API. Hoje usa dados mockados (`mock-data.ts`); para integrar com a API REST em ASP.NET Core, basta alterar `USE_MOCK` para `false` e apontar `API_BASE_URL` em `src/services/api.ts`. Os endpoints previstos já estão documentados nesse arquivo.

## Funcionalidades

- Dashboard com indicadores (meta, total vendido, vendas realizadas, atingimento)
- Progresso da meta com barra de progresso e valor restante
- CRUD de metas e vendas (com status e confirmação de exclusão)
- Cálculos: percentual da meta, valor restante, ticket médio (somente vendas concluídas)
- Relatórios com gráficos (por dia, semana, mês, Meta x Realizado)
- Tela de login com sessão local
- Layout responsivo (sidebar vira menu no celular)

## Equipe

- Lucas Minosso — Scrum Master / Back-end
- Gabriel Sikora Sprada — Front-end
- Bernardo — Banco de Dados
- Felipe Mello — Back-end
